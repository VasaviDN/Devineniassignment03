package demo_Question11;

class Car {
	private String brand;

	public Car(String brand) {
		this.brand = brand;
	}

	public String getBrand() {
		return brand;
	}
}
